// ROS node to publish binary epitope to be used by the adaptive immune function to find appropriate antibodies.
// =============================================================================================================
#include<ros/ros.h>
#include<geometry_msgs/Vector3.h>
#include<robot_adaptive_immune_system/strng.h>
#include<string>
ros::Publisher pub;
std::string current_status;
std::string previous_status;
void callbackStatus(const robot_adaptive_immune_system::strngConstPtr &msg1)
{
    robot_adaptive_immune_system::strng epi;
    current_status = msg1->key;
    epi.key=current_status;
    if(current_status != previous_status)
   {
   pub.publish(epi);
    ros::spinOnce();
    }
    previous_status = current_status;
}
int main(int argc, char **argv)
{
	ros::init(argc, argv, "Epitope");
	ros::NodeHandle nh;
	pub = nh.advertise<robot_adaptive_immune_system::strng>("/epitope",10);
	ros::Subscriber sub = nh.subscribe("/status", 10, callbackStatus);
	ros::spin();
	return 0;
}
