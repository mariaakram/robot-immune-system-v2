#include <ros/ros.h>
#include <geometry_msgs/Pose.h>
#include <sensor_msgs/JointState.h>
#include <geometry_msgs/Quaternion.h>
#include <geometry_msgs/Vector3.h>

int count=0;
    ros::Publisher pub;
	ros::Publisher pub1;
  bool fanC1_off=0;
bool fanC2_off=0;
bool fanML_off=0;
bool fanMR_off=0;
 bool fanC1_on=1;
	bool fanC2_on=1;
	bool fanMR_on=1;
	bool fanML_on=1;
	float a = 1;
	float b = 1;
	float c = 1;
	float d = 1;
	float sum=0;
	float leftTorque = 0;
	float rightTorque = 0;
	float tmp;
	float cells=0;
	geometry_msgs::Quaternion fan;
	geometry_msgs::Quaternion pop;

void callbackDendritiCells(const geometry_msgs::Vector3ConstPtr &dc)
{
cells=dc->x;
}

void callbackInfo_temp(const geometry_msgs::PoseConstPtr &inf)
{
tmp=inf->position.x; //inflammation value

}

void callbackInfo_torq(const sensor_msgs::JointStateConstPtr &trq)
{

	leftTorque = trq->effort[1];
	rightTorque = trq->effort[2];
//for(int j=0;j<6;j++)
//{
if (cells > 1)
{

if(tmp>0.1)
{

if(leftTorque>0.2 || leftTorque < -0.2)
{
	/*if(a>0 && b>0 && c>0)
		{c=c-10;
		a=a-10;
		b=b-10;
}*/
		d=d+2;
	pop.x=a;
	pop.y=b;
	pop.z=c;
	pop.w=d;
	pub1.publish(pop);
	ROS_INFO_STREAM("publishing population");
	ros::spinOnce();

		sum=a+b+c+d;
	fan.x = (((a*fanC1_on)+(b*fanC2_on)+(c*fanMR_on)+(d*fanML_on))/sum);
	pub.publish(fan);
	ROS_INFO_STREAM("Left motor fan has turned on"<<a<<b<<c<<d);
	ros::spinOnce();
}

if(rightTorque>0.2 || rightTorque< -0.2)
{
	/*if(a>0 && b>0 && d>0)
		{d=d-10;
		a=a-10;
		b=b-10;
}*/
		c=c+2;
	pop.x=a;
	pop.y=b;
	pop.z=c;
	pop.w=d;
	pub1.publish(pop);
	ROS_INFO_STREAM("publishing population");
	ros::spinOnce();

		sum=a+b+c+d;
	fan.y = (((a*fanC1_on)+(b*fanC2_on)+(c*fanMR_on)+(d*fanML_on))/sum);
	pub.publish(fan);
	ROS_INFO_STREAM("Right motor fan has turned on"<<a<<b<<c<<d);
	ros::spinOnce();
//}
}}
}
//ROS_INFO_STREAM("Right motor fan is off");
//}

if ((rightTorque<0.1 || rightTorque>-0.1) && (leftTorque<0.1 || leftTorque>-0.1))
{

if(a>2)
{a=a-1;}
if(b>2)
{b=b-1;}
if(c>2)
{c=c-1;}
if(d>2)
{d=d-1;}
	//a = 40;b = 40;c = 40;d = 40;
	pop.x=a;
	pop.y=b;
	pop.z=c;
	pop.w=d;
	pub1.publish(pop);
	ROS_INFO_STREAM("publishing population");
	ros::spinOnce();
}
}
void callbackTempCell1(const geometry_msgs::Vector3ConstPtr &core)
{
	 //geometry_msgs::Vector3 cool;

	float core1=core->x;
	float core2=core->y;
if (cells>0)
{
 for(int i=0;i<6;i++)
{
if(tmp>0.1)
{
if (core1>0.80)
   {
/*if(c>0 && b>0 && d>0)
		{d=d-10;
		c=c-10;
		b=b-10;
}*/

	a=a+2;
	pop.x=a;
	pop.y=b;
	pop.z=c;
	pop.w=d;
	pub1.publish(pop);
	ROS_INFO_STREAM("publishing population");
	ros::spinOnce();

	sum=a+b+c+d;
	fan.z = (((a*fanC1_on)+(b*fanC2_on)+(c*fanMR_on)+(d*fanML_on))/sum);
	pub.publish(fan);
	ROS_INFO_STREAM("core 1 fan has turned on"<<a<<b<<c<<d);
	ros::spinOnce();
}
if (core2>0.80)
   {
/*if(c>0 && a>0 && d>0)
		{d=d-10;
		c=c-10;
		a=a-10;
}*/
		b=b+2;
	pop.x=a;
	pop.y=b;
	pop.z=c;
	pop.w=d;
	pub1.publish(pop);
	ROS_INFO_STREAM("publishing population");
	ros::spinOnce();

		sum=a+b+c+d;
	fan.w = (((a*fanC1_on)+(b*fanC2_on)+(c*fanMR_on)+(d*fanML_on))/sum);
	pub.publish(fan);
	ROS_INFO_STREAM("core 2 fan has turned on"<<a<<b<<c<<d);
	ros::spinOnce();
}
}
}}
if (tmp<0.1 || tmp>-0.1)
{

	if(a>2)
	{a=a-1;}
	if(b>2)
	{b=b-1;}
	if(c>2)
	{c=c-1;}
	if(d>2)
	{d=d-1;}			//a = 40;b = 40;c = 40;d = 40;
	pop.x=a;
	pop.y=b;
	pop.z=c;
	pop.w=d;
	pub1.publish(pop);
	ROS_INFO_STREAM("publishing population");
	ros::spinOnce();
}
}
int main(int argc, char **argv)
{
    ros::init(argc, argv, "T_cells_temp");
    ros::NodeHandle nh;
    pub = nh.advertise<geometry_msgs::Quaternion>("/cooling", 10);
	pub1 = nh.advertise<geometry_msgs::Quaternion>("/CellsPopulation", 10);
	//pub = nh.advertise<geometry_msgs::Vector3>("/motor_cooling", 10);

    	ros::Subscriber sub = nh.subscribe("/Temperature", 10, callbackTempCell1);
	ros::Subscriber sub1 = nh.subscribe("/Inflammation", 10, callbackInfo_temp);
	ros::Subscriber sub2 = nh.subscribe("/joint_state", 10, callbackInfo_torq);
	ros::Subscriber sub3 = nh.subscribe("/DC",10,callbackDendritiCells);
    ros::spin();
    return 0;
}

