#include <ros/ros.h>
#include <geometry_msgs/Vector3.h>
#include <geometry_msgs/Twist.h>
#include <std_msgs/Int32.h>
#include <geometry_msgs/Pose.h>


    ros::Publisher pub;
    float previous_inf=0; float current_inf=0;
	//float value = 0;
	float countt=0;
	float check=0;
float MDC=0;
void callbackDendriticCell(const geometry_msgs::PoseConstPtr &value)
{
    	geometry_msgs::Vector3 dc;
	current_inf=value->position.x; //slope
         if (current_inf > 0.1 && previous_inf > 0.1)
	{countt++;
	check=0+countt;
	ROS_INFO("Count:%f", check);
	ROS_INFO("DCs are maturing");
	if(check>=20)
{	ROS_INFO("DCs are ready to activate T Cells");
        MDC =MDC +1;
	ROS_INFO("DC:%f", MDC);
	dc.x = MDC;
	dc.y=countt;
	pub.publish(dc);
	ROS_INFO("handover to adaptive immune system");
	ros::spinOnce();
}
}
	if (current_inf<0.051 && previous_inf<0.051)
{
	countt=0;
	MDC=0;

}
        //ROS_INFO("previous_inflammation:%f  current_inflammation:%f", previous_inf, current_inf);
        // value=current_value;
	previous_inf=current_inf;
	dc.x = MDC;
	dc.y=countt;
	pub.publish(dc);
	//ROS_INFO("handover to adaptive immune system");
	ros::spinOnce();
}


int main(int argc, char **argv)
{
    ros::init(argc, argv, "DendritiCells");
    ros::NodeHandle nh;
    pub = nh.advertise<geometry_msgs::Vector3>("/DCs", 100);
    ros::Subscriber sub = nh.subscribe("/Inflammation", 10, callbackDendriticCell);
    ros::spin();
    return 0;
}

