// ROS node to determine the core temperatures
// ===========================================
#include <ros/ros.h>
#include <geometry_msgs/Vector3.h>
#include <geometry_msgs/Quaternion.h>
#include <diagnostic_msgs/DiagnosticArray.h>
#include <diagnostic_msgs/DiagnosticStatus.h>
#include <diagnostic_msgs/KeyValue.h>
#include<std_msgs/String.h>

//#include<>
int count=0;
int fan1=0;
int fan2=0;
int fan3=0;
int fan4=0;

    ros::Publisher pub;
 ros::Publisher pub1;
void callbackCPUTemp(const diagnostic_msgs::DiagnosticArray temp);

void callbackCoolTemp(const geometry_msgs::QuaternionConstPtr &cool)
{
fan1=cool->x;
fan2=cool->y;
fan3=cool->z;
fan4=cool->w;
}


void callbackCPUTemp(const diagnostic_msgs::DiagnosticArrayConstPtr &temp)
{
 geometry_msgs::Vector3 tmp;
geometry_msgs::Vector3 at;

char tmprtr[]= "hell";
//{'temp->status[0].values[3].value[0]','temp->status[0].values[3].value[1]','temp->status[0].values[4].value[0]','temp->status[0].values[4].value[1]'};
tmprtr[0]= temp->status[0].values[1].value [0];
tmprtr[1]= temp->status[0].values[1].value[1];
tmprtr[2]= temp->status[0].values[2].value[0];
tmprtr[3]= temp->status[0].values[2].value[1];
float core1_temp=((tmprtr[0]-48)*10)+(tmprtr[1]-48);
float core2_temp=((tmprtr[2]-48)*10)+(tmprtr[3]-48);
float fan=0;
//ROS_INFO_STREAM( "Recieved: "<<"data:" << tmprtr);
ROS_INFO_STREAM( "Recieved: "<<"core1:" << core1_temp);
ROS_INFO_STREAM( "Recieved: "<<"core2:" << core2_temp);
 /*for(int i=0;i<6;i++)
{
if (core1_temp>60 || core2_temp>60)
   {
 fan=1;
ROS_INFO_STREAM( "Temp is getting high ");
count=count+1;

}
else
{
	fan=0;
}}
if(fan==1 && count>=5)
{
core1_temp = core1_temp-2;
core2_temp = core2_temp-2;
ROS_INFO_STREAM( "Temp is getting better ");
count=0;
}
if (fan3>0)
{
core1_temp=core1_temp-5;
}

if (fan4>0)
{
core2_temp = core2_temp-5;
}*/

if (fan3 >= 1 || fan4 >= 1)
{
tmp.x=((0.025*((core1_temp-5)-80))+1); //min_temp=40 and max_temp=80
tmp.y=((0.025*((core2_temp-5)-80))+1);
tmp.z=fan;
}
else
{
tmp.x=((0.02*(core1_temp-80))+1); //min_temp=40 and max_temp=80
tmp.y=((0.02*(core2_temp-80))+1);
tmp.z=fan;
}
pub.publish(tmp);
ros::spinOnce();
ROS_INFO_STREAM( "Recieved: "<<"core1:" << tmp.x);
ROS_INFO_STREAM( "Recieved: "<<"core2:" << tmp.y);
if (fan3 >= 1 || fan4>=1)
{
at.x=core1_temp-5;
at.y=core2_temp-5;
}
else
{
at.x=core1_temp;
at.y=core2_temp;
}
pub1.publish(at);
ros::spinOnce();
 }
int main(int argc, char **argv)
{
    ros::init(argc, argv, "cpu_temp");
    ros::NodeHandle nh;
    pub = nh.advertise<geometry_msgs::Vector3>("/Temperature", 10);
	pub1 = nh.advertise<geometry_msgs::Vector3>("/AT", 10);

    ros::Subscriber sub = nh.subscribe("/diagnostics", 100, callbackCPUTemp);
	ros::Subscriber sub1 = nh.subscribe("/cooling", 100, callbackCoolTemp);
    ros::spin();
    return 0;
}

//string abc= "temp->status[0].values[3].value[1]";
/*int i=0;
while(i!=555)
{

if(core1_temp<60 && core2_temp<60)
     i==555;
else
 i++
}*/
//ROS_INFO_STREAM( "Recieved: "<<"data:" << temp->status[0].values[3].value[0]<<temp->status[0].values[3].value[1]<<temp->status[0].values[4].value[0]<<temp->status[0].values[4].value[1]);
/*ROS_INFO("temperature:%f", tmprtr);
  if (core1_temp>60 || core2_temp>60)
   {
     for(int i=0;i<999999;i++)
      {
          int j=0;
          j=j*2;
          j=j++;
      }
for(int i=0;i<999999;i++)
      {
          int j=0;
          j=j*2;
          j=j++;
      }
for(int i=0;i<999999;i++)
      {
          int j=0;
          j=j*2;
          j=j++;
      }
for(int i=0;i<999999;i++)
      {
          int j=0;
          j=j*2;
          j=j++;
      }
{ ROS_INFO("CPU_temp_is_below_threshold");}
else {ROS_INFO("CPU_temp_is_rising");}
tmp.x=tmprtr;*/
