// ROS node to calculate Energy consumed by the robot on the basis of power consumption over time
// ==============================================================================================
#include <ros/ros.h>
#include <sensor_msgs/JointState.h>
#include <geometry_msgs/Vector3.h>
//#include <actionlib_msgs/GoalStatusArray.h>

    ros::Publisher pub;
	ros::Publisher pub1;
    void callbackTorque(const sensor_msgs::JointState torq);
    double initial_energy=5000;
    float Left_joint_power;
    float Right_joint_power;
	float gripper_power;
    double energy_left=0;
     double z =5000;

 double energy(double p1, double p2, double p3, double& z)
{
	geometry_msgs::Vector3 nrg;
    double consumed_energy=0;
if(p1<0){
p1=-p1;}
if(p2<0){
p2=-p2;}
if(p3<0){
p3=-p3;}
	consumed_energy=((p1+p2)*0.05 +(p3*0.01));
	nrg.x=consumed_energy;
	pub1.publish(nrg);
    initial_energy=z;
double energy = initial_energy-consumed_energy;
    z=energy;
    return energy;
}

void callbackTorque(const sensor_msgs::JointStateConstPtr &joint)
{
 geometry_msgs::Vector3 msg;
    //float consumption=0;
   float leftTorque = joint->effort[0]; //Torque of left motor
  float rightTorque = joint->effort[1];//Torque of right motor
   // float leftTorque = joint->effort[90]; //Torque of left motor ---FOR S2
   // float rightTorque = joint->effort[89];//Torque of right motor ---FOR S2

   Left_joint_power= ((joint->velocity[0]*joint->effort[0])/0.07);
   Right_joint_power= ((joint->velocity[1]*joint->effort[1])/0.07);
   // Left_joint_power= ((joint->velocity[90]*joint->effort[90])/0.07); //---FOR S2
   // Right_joint_power= ((joint->velocity[89]*joint->effort[89])/0.07);// ---FOR S2

   // Left_joint_power= ((joint->velocity[0]*joint->effort[0]*100)/0.07); // ---FOR e-puck
  //  Right_joint_power= ((joint->velocity[1]*joint->effort[1]*100)/0.07); // ---FOR e-puck
	gripper_power = joint->effort[4];//(joint->velocity[4]*joint->effort[4]);
   // gripper_power = joint->effort[88]; // ---FOR S2
//left:225,right:224,gripper:223.

    ROS_INFO("Left_joint_vel:%f  Right_joint_vel:%f", joint->velocity[0], joint->velocity[1]);
    ROS_INFO("Left_joint_torq:%f  Right_joint_torq:%f", joint->effort[0], joint->effort[1]);
    ROS_INFO("Left_joint_pow:%f  Right_joint_pow:%f", Left_joint_power, Right_joint_power);
    //consumption=(Left_joint_power+Right_joint_power)*0.05;
  //  float remaining_energy=starting_energy-consumption;
  energy_left=energy(Left_joint_power,Right_joint_power,gripper_power,z);
    ROS_INFO("Energy_remained:%f",energy_left);
  z=energy_left;
if (energy_left<2000)
{ROS_INFO("Energy_is_getting_low");}
//msg.header.stamp=ros::Time::now();
msg.x=Left_joint_power;
msg.y=Right_joint_power;
msg.z=energy_left;
pub.publish(msg);
 }
int main(int argc, char **argv)
{
    ros::init(argc, argv, "energy");
    ros::NodeHandle nh;
    pub = nh.advertise<geometry_msgs::Vector3>("/Energy", 10);
	pub1 = nh.advertise<geometry_msgs::Vector3>("/energy_consumption", 10);
    ros::Subscriber sub = nh.subscribe("/joint_state", 10, callbackTorque);
    //ros::Rate rate(10);
     ros::spin();
    return 0;
}


/*void callback(const actionlib_msgs::GoalStatusArray sts)
{

//if (!sts.status_list.empty())
   //{
     //actionlib_msgs::GoalStatus goalStatus = sts.status_list[0];

   //}
ROS_INFO("Status:%f", sts.status_list[0]);   }*/
     //sub = nh.subscribe("/move_base/status", 10, callbackStatus);
   // sub = nh.subscribe("/cmd_vel", 10, callbackVelocity);
   // pub = nh.advertise<geometry_msgs::Vector3>("/Energy", 10);
 // starting_energy=remaining_energy;

//void callbackStatus(const actionlib_msgs::GoalStatusArray sts);
 //geometry_msgs::Vector3 enr;
