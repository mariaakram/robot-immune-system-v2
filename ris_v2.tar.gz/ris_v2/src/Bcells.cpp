// ROS node to execute adaptive immune functions of clonal selection through affinity evaluation and mutation to find best matched antibodies.
// ===========================================================================================================================================
#include <iostream>
#include<string>
#include<vector>
#include <algorithm>
using namespace std;
#include<map>
#include<ros/ros.h>
#include<geometry_msgs/Vector3.h>
#include<geometry_msgs/Twist.h>
#include<geometry_msgs/Quaternion.h>
#include<geometry_msgs/Pose.h>
#include<robot_adaptive_immune_system/strng.h>
#include<robot_adaptive_immune_system/data.h>
#include<robot_adaptive_immune_system/DataArray.h>
std::string epitope_antigen;
geometry_msgs::Vector3 antigenNo;
string previous_input;
string current_input;
ros::Publisher pub1;
ros::Publisher pub;
ros::Publisher pub2;
ros::Publisher pub3;
geometry_msgs::Twist vel;
float depletion_rate;
float mem;
geometry_msgs::Quaternion fan;
int curr_action;
int indexx = -1;
geometry_msgs::Vector3 it;
float j;
float w;
int ii = 0;
float mDCT, mDCE;
string   current_epi;

class Mapping
{
    public:
    int action;
    float weight;
    string key;
    int matchCount;
    string matcher;
};

struct less_than_key
{
    inline bool operator() (const Mapping& mapping1, const Mapping& mapping2)
    {
        return (mapping1.matchCount > mapping2.matchCount);
    }
};

// Responsible for generating binary array
vector<string> generateBinaryArray(int n)
{
cout<<"SSTRING GENERATION"<<endl;
   vector<string> arr;

        if (n <= 0)
          return arr;
    arr.push_back("0");
    arr.push_back("1");

    for (int i = 2; i < (1<<n); i = i<<1)
        {
        // Enter the previously generated codes again in arr[] in reverse
        // order. Nor arr[] has double number of codes.
         for (int j = i-1 ; j >= 0 ; j--)
             arr.push_back(arr[j]);

        // append 0 to the first half
         for (int j = 0 ; j < i ; j++)
             arr[j] = "0" + arr[j];

        // append 1 to the second half
         for (int j = i ; j < 2*i ; j++)
             arr[j] = "1" + arr[j];
       }

}

//Responsible for generate mappings
vector<Mapping> generateMappings(vector<string> arr) {
 ROS_INFO("GENERATE MAPPINGS");
vector<Mapping> resultSet;
int d = 1;
for (int i = 0 ; i < arr.size() ; i++ )
      {

        Mapping mapping;
        mapping.action = d;
        mapping.weight = 0.5;
        mapping.key = arr[i];

        resultSet.push_back(mapping);
        d++;

        if(d==21)
        {
            d=1;
        }

    }

    return resultSet;
}

vector<string> result = generateBinaryArray(10);
vector<Mapping> sortedResults = generateMappings(result);

//Responsible for sorting array of mapping according to the best matches based on input
vector<Mapping> sortResultsAccordingToTheBestMatch(vector<Mapping> mappings , string input) {
    ROS_INFO("SORTED FOR BEST MATCH");
    for(int i = 0 ; i < mappings.size(); i++ ) {
            int count = 0;
            for(int j = 0; j < 9 ; j++) {
                if (mappings[i].key[j] != input[j]) {
                    count++;
                }
            }
            mappings[i].matchCount = count;
            count = 0;
    }
    sort(mappings.begin(), mappings.end(), less_than_key());
       return mappings;
}


vector<Mapping> mutation(vector<Mapping> sortedResults) {

    cout<<"MUTAION START"<<endl;

    for(int j = 0 ; j < sortedResults.size(); j++) {
        if (sortedResults[j].matchCount < 8 ) {
            if (sortedResults[j].key[0] == '0') {
                sortedResults[j].key[0] = '1';
            } else {
                sortedResults[j].key[0] = '0';
            }
            if (sortedResults[j].key[7] == '0') {
                sortedResults[j].key[7] = '1';
            } else {
                sortedResults[j].key[7] = '0';
            }
            if (sortedResults[j].key[4] == '0') {
                sortedResults[j].key[4] = '1';
            } else {
                sortedResults[j].key[4] = '0';
            }
        }
    }

    return sortResultsAccordingToTheBestMatch(sortedResults, epitope_antigen);
}

void moveObject(float linearVelocity, float angularVelocity) {
    vel.linear.x = linearVelocity;
    vel.angular.z = angularVelocity ;
    pub1.publish(vel);
    ros::Duration(0.1).sleep();
    ros::spinOnce();
}

void callbackIteration(const geometry_msgs::Vector3ConstPtr &msgi)
{
j=msgi->x;
}
void coolObject(bool motorLeft, bool motorRight, bool controller1, bool controller2) {
     fan.x = motorLeft;
    fan.y = motorRight;
    fan.z = controller1;
    fan.w = controller2;
    pub.publish(fan);
    ros::Duration(0.1).sleep();
    ros::spinOnce();
}
void  possible_actions()
 {
    cout<<"ACTION EXECUTION"<<endl;
        current_epi = epitope_antigen;
        string check="0000000000";
        float lVeloty;
        float aVelocity;
        bool mLeft;
        bool mRight;
        bool core1;
        bool core2;
        for (ii = 0; ii < sortedResults.size(); ii++)
         {
          j++;
            it.y =w;//++;
         it.x=j;
         it.z=mem;
        pub3.publish(it);
       ros::spinOnce();
            cout<<"Iteration No: "<<j<<endl;
               if (sortedResults[ii].action == 1) {
                    lVeloty = ((double)rand()/((double)RAND_MAX+1))+1; //to generate a random number between 0-1 & -ve sign to reverse motion;
                    aVelocity = 0;
                    cout<<"MOVE FORWARD"<<endl;
               } else if (sortedResults[ii].action == 3) {
                    lVeloty = ((double)rand()/((double)RAND_MAX+1)); //to generate a random number between 0-1 & -ve sign to reverse motion;
                    aVelocity = 0;
                    cout<<"MOVE FORWARD SLOWLY"<<endl;
               } else if (sortedResults[ii].action == 2) {
                    lVeloty = -((double)rand()/((double)RAND_MAX+1))-1; //to generate a random number between 0-1 & -ve sign to reverse motion;
                    aVelocity = -0;
                    cout<<"MOVE BACKWARD"<<endl;
                } else if (sortedResults[ii].action == 4) {
                    lVeloty = -((double)rand()/((double)RAND_MAX+1)); //to generate a random number between 0-1 & -ve sign to reverse motion;
                    aVelocity = -0;
                    cout<<"MOVE BACKWARD SLOWLY"<<endl;

               } else if (sortedResults[ii].action == 16 || sortedResults[ii].action == 15) {
                    lVeloty = 0;
                    aVelocity = -((double)rand()/((double)RAND_MAX+1))-1;
                    cout<<"TURN RIGHT"<<endl;
               } else if (sortedResults[ii].action == 17 || sortedResults[ii].action == 19) {
                     lVeloty = 0;
                    aVelocity = ((double)rand()/((double)RAND_MAX+1))+1;
                    cout<<"TURN LEFT"<<endl;
               } else if (sortedResults[ii].action == 10) {
                    mLeft = 0;
                    mRight = 1;
                    core1 = 0;
                    core2 = 0;
                    cout<<"TURN RIGHT MOTOR FAN ON"<<endl;
                } else if (sortedResults[ii].action == 13) {
                    mLeft = 1;
                    mRight = 0;
                    core1 = 0;
                    core2 = 0;
                    cout<<"TURN LEFT MOTOR FAN ON"<<endl;
                } else if (sortedResults[ii].action == 11) {
                    mLeft = 0;
                    mRight = 0;
                    core1 = 1;
                    core2 = 0;
                    cout<<"TURN CONTROLLER 1 FAN ON"<<endl;
                } else if (sortedResults[ii].action == 14) {
                    mLeft = 0;
                    mRight = 0;
                    core1 = 0;
                    core2 = 1;
                    cout<<"TURN CONTROLLER 2 FAN ON"<<endl;
                } else if (sortedResults[ii].action == 5) {
                    mLeft = 1;
                    mRight = 0;
                    core1 = 0;
                    core2 = 0;
                    cout<<"TURN LEFT MOTOR FAN ON"<<endl;
                    lVeloty = 0;
                    aVelocity = ((double)rand()/((double)RAND_MAX+1))+1;
                    cout<<"TURN LEFT"<<endl;
               } else if (sortedResults[ii].action == 9) {
                    mLeft = 1;
                    mRight = 0;
                    core1 = 0;
                    core2 = 0;
                    cout<<"TURN LEFT MOTOR FAN ON"<<endl;
                    lVeloty = 0;
                    aVelocity = -((double)rand()/((double)RAND_MAX+1))-1;
                    cout<<"TURN RIGHT"<<endl;
               } else if (sortedResults[ii].action == 6) {
                    mLeft = 0;
                    mRight = 1;
                    core1 = 0;
                    core2 = 0;
                    cout<<"TURN RIGHT MOTOR FAN ON"<<endl;
                    lVeloty = 0;
                    aVelocity = -((double)rand()/((double)RAND_MAX+1))-1;
                    cout<<"TURN RIGHT"<<endl;
               } else if (sortedResults[ii].action == 12) {
                    mLeft = 0;
                    mRight = 1;
                    core1 = 0;
                    core2 = 0;
                    cout<<"TURN RIGHT MOTOR FAN ON"<<endl;
                    lVeloty = 0;
                    aVelocity = ((double)rand()/((double)RAND_MAX+1))+1;
                    cout<<"TURN LEFT"<<endl;
               } else if (sortedResults[ii].action == 7) {
                    mLeft = 0;
                    mRight = 0;
                    core1 = 1;
                    core2 = 0;
                    cout<<"TURN CONTROLLER 1 FAN ON"<<endl;
                     lVeloty = ((double)rand()/((double)RAND_MAX+1))+1; //to generate a random number between 0-1 & -ve sign to reverse motion;
                    aVelocity = 0;
                    cout<<"MOVE FORWARD"<<endl;
               } else if (sortedResults[ii].action == 18) {
                    mLeft = 0;
                    mRight = 0;
                    core1 = 1;
                    core2 = 0;
                    cout<<"TURN CONTROLLER 1 FAN ON"<<endl;
                    lVeloty = -((double)rand()/((double)RAND_MAX+1))-1; //to generate a random number between 0-1 & -ve sign to reverse motion;
                    aVelocity = 0;
                    cout<<"MOVE BACKWARD"<<endl;
               } else if (sortedResults[ii].action == 8) {
                    mLeft = 0;
                    mRight = 0;
                    core1 = 0;
                    core2 = 1;
                    cout<<"TURN CONTROLLER 2 FAN ON"<<endl;
                     lVeloty = -((double)rand()/((double)RAND_MAX+1))-1; //to generate a random number between 0-1 & -ve sign to reverse motion;
                    aVelocity = 0;
                    cout<<"MOVE BACKWARD"<<endl;
               } else if (sortedResults[ii].action == 20) {
                    mLeft = 0;
                    mRight = 0;
                    core1 = 0;
                    core2 = 1;
                    cout<<"TURN CONTROLLER 2 FAN ON"<<endl;
                    lVeloty = ((double)rand()/((double)RAND_MAX+1))+1; //to generate a random number between 0-1 & -ve sign to reverse motion;
                    aVelocity = 0;
                    cout<<"MOVE FORWARD"<<endl;
               }
           if (sortedResults[ii].weight > 0.30) {
               geometry_msgs::Vector3 current_action;
               curr_action = sortedResults[ii].action;
               current_action.x = sortedResults[ii].action;
                pub2.publish(current_action);
                moveObject(lVeloty, aVelocity);
                coolObject(mLeft,mRight,core1,core2);
                     if (check == epitope_antigen) {
                  cout<<"PROBLEM SOLVED"<<endl;
                  int coin;
                  coin++;
                       sortedResults[ii].matcher = current_epi;
                              mem ++;//}

                            if (sortedResults[ii].weight<1)
                                {
                                    for (int i = 0 ; i < sortedResults.size(); i++)
                                    {
                                    if (sortedResults[i].action == curr_action)
                                        {
                                        sortedResults[i].weight=sortedResults[i].weight+0.01;

                                        }
                                    }
                                    cout<<"weight"<<sortedResults[ii].weight<<endl;
                        return;
                    }
                            else
                            {
                                if(sortedResults[ii].weight > 0) {
                                for (int i = 0 ; i < sortedResults.size(); i++)
                                    {
                                    if (sortedResults[i].action == curr_action)
                                        {
                                sortedResults[i].weight=sortedResults[i].weight-0.01;

                                        }
                                    }
                                    cout<<"weight"<<sortedResults[ii].weight<<endl;
                                }
                            }
                            }
                    if (ii==4)
                    {
                       sortedResults = mutation(sortedResults);
                       ii = 0;
                    }
        }
        }
    }

        Mapping memory_actions(Mapping solution)
 {
    cout<<"MEMORY ACTION EXECUTION"<<endl;
        current_epi = epitope_antigen;
        string check="0000000000";
        float lVeloty;
        float aVelocity;
        bool mLeft;
        bool mRight;
        bool core1;
        bool core2;

                if (sortedResults[ii].action == 1) {
                    lVeloty = ((double)rand()/((double)RAND_MAX+1))+1; //to generate a random number between 0-1 & -ve sign to reverse motion;
                    aVelocity = 0;
                    cout<<"MOVE FORWARD"<<endl;
               } else if (sortedResults[ii].action == 3) {
                    lVeloty = ((double)rand()/((double)RAND_MAX+1)); //to generate a random number between 0-1 & -ve sign to reverse motion;
                    aVelocity = 0;
                    cout<<"MOVE FORWARD SLOWLY"<<endl;
               } else if (sortedResults[ii].action == 2) {
                    lVeloty = -((double)rand()/((double)RAND_MAX+1))-1; //to generate a random number between 0-1 & -ve sign to reverse motion;
                    aVelocity = -0;
                    cout<<"MOVE BACKWARD"<<endl;
                } else if (sortedResults[ii].action == 4) {
                    lVeloty = -((double)rand()/((double)RAND_MAX+1)); //to generate a random number between 0-1 & -ve sign to reverse motion;
                    aVelocity = -0;
                    cout<<"MOVE BACKWARD SLOWLY"<<endl;
               } else if (solution.action == 16 || solution.action == 15) {
                    lVeloty = 0;
                    aVelocity = -((double)rand()/((double)RAND_MAX+1))-1;
                    cout<<"TURN RIGHT"<<endl;
               } else if (solution.action == 17 || solution.action == 19) {
                     lVeloty = 0;
                    aVelocity = ((double)rand()/((double)RAND_MAX+1))+1;
                    cout<<"TURN LEFT"<<endl;
               } else if (solution.action == 10) {
                    mLeft = 0;
                    mRight = 1;
                    core1 = 0;
                    core2 = 0;
                    cout<<"TURN RIGHT MOTOR FAN ON"<<endl;
                } else if (solution.action == 13) {
                    mLeft = 1;
                    mRight = 0;
                    core1 = 0;
                    core2 = 0;
                    cout<<"TURN LEFT MOTOR FAN ON"<<endl;
                } else if (solution.action == 11) {
                    mLeft = 0;
                    mRight = 0;
                    core1 = 1;
                    core2 = 0;
                    cout<<"TURN CONTROLLER 1 FAN ON"<<endl;
                } else if (solution.action == 14) {
                    mLeft = 0;
                    mRight = 0;
                    core1 = 0;
                    core2 = 1;
                    cout<<"TURN CONTROLLER 2 FAN ON"<<endl;
                } else if (solution.action == 5) {
                    mLeft = 1;
                    mRight = 0;
                    core1 = 0;
                    core2 = 0;
                    cout<<"TURN LEFT MOTOR FAN ON"<<endl;
                    lVeloty = 0;
                    aVelocity = ((double)rand()/((double)RAND_MAX+1))+1;
                    cout<<"TURN LEFT"<<endl;
               } else if (solution.action == 9) {
                    mLeft = 1;
                    mRight = 0;
                    core1 = 0;
                    core2 = 0;
                    cout<<"TURN LEFT MOTOR FAN ON"<<endl;
                    lVeloty = 0;
                    aVelocity = -((double)rand()/((double)RAND_MAX+1))-1;
                    cout<<"TURN RIGHT"<<endl;
               } else if (solution.action == 6) {
                    mLeft = 0;
                    mRight = 1;
                    core1 = 0;
                    core2 = 0;
                    cout<<"TURN RIGHT MOTOR FAN ON"<<endl;
                    lVeloty = 0;
                    aVelocity = -((double)rand()/((double)RAND_MAX+1))-1;
                    cout<<"TURN RIGHT"<<endl;
               } else if (solution.action == 12) {
                    mLeft = 0;
                    mRight = 1;
                    core1 = 0;
                    core2 = 0;
                    cout<<"TURN RIGHT MOTOR FAN ON"<<endl;
                    lVeloty = 0;
                    aVelocity = ((double)rand()/((double)RAND_MAX+1))+1;
                    cout<<"TURN LEFT"<<endl;
               } else if (solution.action == 7) {
                    mLeft = 0;
                    mRight = 0;
                    core1 = 1;
                    core2 = 0;
                    cout<<"TURN CONTROLLER 1 FAN ON"<<endl;
                     lVeloty = ((double)rand()/((double)RAND_MAX+1))+1; //to generate a random number between 0-1 & -ve sign to reverse motion;
                    aVelocity = 0;
                    cout<<"MOVE FORWARD"<<endl;
               } else if (solution.action == 18) {
                    mLeft = 0;
                    mRight = 0;
                    core1 = 1;
                    core2 = 0;
                    cout<<"TURN CONTROLLER 1 FAN ON"<<endl;
                    lVeloty = -((double)rand()/((double)RAND_MAX+1))-1; //to generate a random number between 0-1 & -ve sign to reverse motion;
                    aVelocity = 0;
                    cout<<"MOVE BACKWARD"<<endl;
               } else if (solution.action == 8) {
                    mLeft = 0;
                    mRight = 0;
                    core1 = 0;
                    core2 = 1;
                    cout<<"TURN CONTROLLER 2 FAN ON"<<endl;
                     lVeloty = -((double)rand()/((double)RAND_MAX+1))-1; //to generate a random number between 0-1 & -ve sign to reverse motion;
                    aVelocity = 0;
                    cout<<"MOVE BACKWARD"<<endl;
               } else if (solution.action == 20) {
                    mLeft = 0;
                    mRight = 0;
                    core1 = 0;
                    core2 = 1;
                    cout<<"TURN CONTROLLER 2 FAN ON"<<endl;
                    lVeloty = ((double)rand()/((double)RAND_MAX+1))+1; //to generate a random number between 0-1 & -ve sign to reverse motion;
                    aVelocity = 0;
                    cout<<"MOVE FORWARD"<<endl;
               }

           if (solution.weight > 0.30) {
                moveObject(lVeloty, aVelocity);
                coolObject(mLeft,mRight,core1,core2);
                  if (check == epitope_antigen && depletion_rate < 0.15) {
                            if (solution.weight<1)
                                {
                                    solution.weight=solution.weight+0.01;
;
                                }

                        return solution;
                    }

                    else
                    {
                       if(solution.weight > 0) {
                        solution.weight=solution.weight-0.01;
                       }
                       return solution;
                       possible_actions();
                    }
              }

        }
void callbackAntigen(const robot_adaptive_immune_system::strngConstPtr &msg1)
{
    w++;
    epitope_antigen =msg1->key;
    current_input = epitope_antigen;
    bool matched = false;

   if (current_input == "0000000000")
    {
        j=0;
        return;}
    else if (mDCE > 40 || mDCT > 40)
    {
        sortedResults = sortResultsAccordingToTheBestMatch(sortedResults, epitope_antigen);
    for(int k = 0; k < sortedResults.size(); k++ ) {
        if (sortedResults[k].matcher == current_input) {
            vector<Mapping> matchedObject;
            matchedObject.push_back(sortedResults[k]);
            Mapping mem_soln;
            mem_soln = sortedResults[k];
            Mapping memoryResults = memory_actions(mem_soln);
            sortedResults[k] = memoryResults;
            matched = true;
            }
        }
        if(epitope_antigen != "0000000000")
            {
                sortedResults = sortResultsAccordingToTheBestMatch(sortedResults, epitope_antigen);
                possible_actions();
            }
        }
}
void callbackThelper(const geometry_msgs::Vector3ConstPtr &msg)
{
    int helper=msg->x;
    it.y =0;//++;
    it.x=0;
    pub3.publish(it);
    ros::spinOnce();
}

void callbackInflammation(const geometry_msgs::PoseConstPtr &msg6)
{
    depletion_rate=msg6->position.x;
    it.x=0;
    it.y =0;
    it.z=mem;
    pub3.publish(it);
    ros::spinOnce();
}

void callbackDCE(const geometry_msgs::Vector3ConstPtr &msg7)
{
    mDCE=msg7->y;
}
void callbackDCT(const geometry_msgs::Vector3ConstPtr &msg8)
{
    mDCT=msg8->y;
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "Bcells_Antibodies");
    ros::NodeHandle nh;
  	pub = nh.advertise<geometry_msgs::Quaternion>("/cooling", 1);
	pub1 = nh.advertise<geometry_msgs::Twist>("/cmd_vel", 1);
	pub2 = nh.advertise<geometry_msgs::Vector3>("/current_action", 1);
	pub3 = nh.advertise<geometry_msgs::Vector3>("/iteration", 1);
	//ros::Subscriber sub1 = nh.subscribe("/iteration", 1, callbackIteration);
	ros::Subscriber sub2 = nh.subscribe("/epitope",10, callbackAntigen);
	ros::Subscriber sub3 = nh.subscribe("/t_helper", 10, callbackThelper);
	ros::Subscriber sub4 = nh.subscribe("/Inflammation", 10, callbackInflammation);
	ros::Subscriber sub5 = nh.subscribe("/DC", 10, callbackDCT);
	ros::Subscriber sub6 = nh.subscribe("/DCs", 10, callbackDCE);
    ros::spin();
        return 0;
}
