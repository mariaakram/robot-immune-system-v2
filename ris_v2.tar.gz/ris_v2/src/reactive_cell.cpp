// ROS node to mobilize Reactive Immune Cells of Innate Immunity against fault to perform recovery actions
// =======================================================================================================
#include <ros/ros.h>
#include <geometry_msgs/Vector3.h>
#include <geometry_msgs/Pose.h>
#include <geometry_msgs/Twist.h>
#include <std_msgs/Int32.h>


    ros::Publisher pub;
    void callbackTorque(const geometry_msgs::Vector3 inf);
    float previous_value=0; float current_value=0;
	float value = 0;
	float count=0;
	float check=0;
void callbackReactiveCell(const geometry_msgs::PoseConstPtr &inf)
{
    	geometry_msgs::Twist vel;
	current_value=inf->position.x; // slope
         if (current_value > 0.06 && previous_value > 0.06)
	{count++;
	check=0+count;
	ROS_INFO("Count:%f", check);
	if(check>10)
{
        float cell_left_x = 0; 
	float cell_left_z = 6;
	float cell_right_x = 0;
	float cell_right_z = -6;
	float cell_front_x = -6;
	float cell_front_z = 0;
	float cell_back_x = 6;
	float cell_back_z =0;
	float a = rand()%50;
	float b = rand()%50;
	float c = rand()%50;
	float d = rand()%50;
	float sum=a+b+c+d;

	vel.linear.x = (((a*cell_left_x)+(b*cell_right_x)+(c*cell_back_x)+(d*cell_front_x))/sum); 
	vel.angular.z = (((a*cell_left_z)+(b*cell_right_z)+(c*cell_back_z)+(d*cell_front_z))/sum); 
	pub.publish(vel);
	ROS_INFO("publishing random");
	ros::spinOnce();
}
}		
	if (current_value<0.06 && previous_value<0.06)
{
	count=0;
	
}
        ROS_INFO("previous_inflammation:%f  current_inflammation:%f", previous_value, current_value);	
         value=current_value;
	previous_value=value;
}


int main(int argc, char **argv)
{
    ros::init(argc, argv, "ReactiveCell");
    ros::NodeHandle nh;
    pub = nh.advertise<geometry_msgs::Twist>("/cmd_vel", 100);
    ros::Subscriber sub = nh.subscribe("/Inflammation", 10, callbackReactiveCell);
    //ros::Subscriber sub_ = nh.subscribe("/Hit", 10, callbackBump);
    ros::spin();
    return 0;
}

