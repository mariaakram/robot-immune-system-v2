// ROS node to calculate Inflammation on the basis of energy, temperature , robot performance and battery level.
// =============================================================================================================
#include <ros/ros.h>
#include <geometry_msgs/Pose.h>
#include <geometry_msgs/Vector3.h>
    ros::Publisher pub;
    void callbackEnergyConsumption(const geometry_msgs::Vector3 enrg);
	void callbackHeatConsumption(const geometry_msgs::Vector3 heet);
	void callbackPerformance(const geometry_msgs::Vector3 perf);
    float previous_energy=5000,current_energy=0;
    double nflmtn;
float energy_function, heat_function, performance_function, battery_function;
/*double inflammation(double e1,double e2, double delta_t)
{
double inf=(e2-e1)/delta_t;
return inf;
}*/
void callbackEnergy(const geometry_msgs::Vector3ConstPtr &enrg)
{
 geometry_msgs::Pose msg;
    ros::Time current_time, last_time;
    current_time = ros::Time::now();
    float current_energy = enrg->z; //remaining energy
    double dt = ((current_time - last_time).toSec()/1000000000);///1000000000
//ROS_INFO("previous_time:%d  current_time:%d delta_t:%d", last_time, current_time, dt);
   //double nflmtn=inflammation(current_energy,previous_energy,dt);
    float slope=((previous_energy-current_energy)/dt);
    ROS_INFO("previous_energy:%f  current_energy:%f delta_t:%f energy_decline_rate:%f", previous_energy, current_energy, dt, slope);
    last_time = current_time;
    previous_energy = current_energy;
   energy_function=(1*(slope-1)+1);//(0.25*(slope-4)+1);
ROS_INFO("energy_function:%f", energy_function);
if(current_energy<1000) //battery low
{energy_function=1;}
  if (slope>0.1)
{ ROS_INFO("System_is_getting_unstable");}
else {ROS_INFO("Robot_is_fine");}
float Z=energy_function+heat_function+performance_function;
float inflammation=(0.333*(Z-3)+1);
ROS_INFO("inflammation:%f", inflammation);
msg.position.x=slope;
msg.position.y=inflammation;
msg.position.z=heat_function;
msg.orientation.x=performance_function;
msg.orientation.y=energy_function;
pub.publish(msg);
ros::spinOnce();
 }
void callbackHeat(const geometry_msgs::Vector3ConstPtr &heet)
{
 //geometry_msgs::Vector3 ht;
   
    
  	float heat_core1 = heet->x;
	float heat_core2 = heet->y;
	bool exhaust=heet->z;
	heat_function=((heat_core1 + heat_core2)/2);

   if(heat_core1 > 75 || heat_core2 >75)
{
heat_function=1;
 }
}
void callbackPerformance(const geometry_msgs::Vector3ConstPtr &perf)
{
  	float dis = perf->x;

if(dis>0.1)
{
for (int i=1;i<20;i++)
{
performance_function=1;
}
//performance_function=0;
}
  }
int main(int argc, char **argv)
{
    ros::init(argc, argv, "inflammation");
    ros::NodeHandle nh;
    pub = nh.advertise<geometry_msgs::Pose>("/Inflammation", 10);
    ros::Subscriber sub = nh.subscribe("/Energy", 10, callbackEnergy);
	ros::Subscriber sub1 = nh.subscribe("/Temperature", 10, callbackHeat);
	ros::Subscriber sub2 = nh.subscribe("/Distance", 10, callbackPerformance);
    ros::spin();
    return 0;
}

