// ROS node to publish health status of motors, controllers, bump sensors, battery, gripper and laser scanner of the robot.
// ========================================================================================================================
#include<ros/ros.h>
#include<geometry_msgs/Vector3.h>
#include<geometry_msgs/Twist.h>
#include <geometry_msgs/Pose.h>
#include <sensor_msgs/JointState.h>
#include <geometry_msgs/Quaternion.h>
#include<string>
#include<sensor_msgs/LaserScan.h>
#include<std_msgs/String.h>
#include<robot_adaptive_immune_system/strng.h>
void callbackBumpSensors(const geometry_msgs::Pose);
robot_adaptive_immune_system::strng binary_string;
char current_epitope[10]={0};
//char *previous_epitope=NULL;
char antigen[16]={0};
ros::Publisher pub;
ros::Publisher pub1;
float depletion_rate;
std::string input;
int count;
int county;
//std_msgs::String check;
void callbackThelper(const geometry_msgs::Vector3ConstPtr &msg)
{
int helper=msg->x;
}

void callbackControllers(const geometry_msgs::Vector3ConstPtr &msg1)
{
int core1_temp=msg1->x;
int core2_temp=msg1->y;
if (core1_temp > 75)
{
antigen[0]='0';
antigen[1]='1';
antigen[2]='1';
current_epitope[0]=antigen[1];
current_epitope[1]=antigen[2];}
/*else
{antigen[0]='0';
antigen[1]='0';
antigen[2]='0';
current_epitope[0]=antigen[1];
current_epitope[1]=antigen[2];
//ROS_INFO_STREAM("EPITOPE"<<epitope[0]<<epitope[1]);ros::spinOnce();
//check.data=epitope[0];
//ROS_INFO_STREAM("CHECK"<<check.data);ros::spinOnce();
//binary_string.key=epitope[1];
//binary_string.key=epitope[1];
//binary_string.key=epitope[2];
//ROS_INFO_STREAM("KEY"<<binary_string.key);ros::spinOnce();
}*/
if (core2_temp > 75)
{
antigen[0]='1';
antigen[1]='1';
antigen[2]='1';
current_epitope[0]=antigen[1];
current_epitope[1]=antigen[2];}
else if ((core1_temp < 72) && core2_temp < 72)
{antigen[0]='1';
antigen[1]='0';
antigen[2]='0';
current_epitope[0]=antigen[1];
current_epitope[1]=antigen[2];
}
 //binary_string = epitope[0]epitope[1]epitope[2]epitope[3]epitope[4]epitope[5]epitope[5]epitope[6]epitope[7]epitope[8];
//string binary=binary_string->key;
}
void callbackMotors(const sensor_msgs::JointStateConstPtr &msg2)
{
	float leftMotorTorque = msg2->effort[0]; //Torque of left motor
	float rightMotorTorque = msg2->effort[1];//Torque of right motor
	//float leftMotorTorque = msg2->effort[90]; //Torque of left motor ---FORS2
	//float rightMotorTorque = msg2->effort[89];//Torque of right motor ---FORS2
if (leftMotorTorque>0.3 || leftMotorTorque<-0.3)
{

count++;
    if (count >200)
    {
        antigen[6]='0';
        antigen[7]='1';
        antigen[8]='1';
        current_epitope[4]=antigen[7];
        current_epitope[5]=antigen[8];
        count=0;
    }
}

else if ((leftMotorTorque < 0.3 || leftMotorTorque > -0.3) && (rightMotorTorque < 0.3 || rightMotorTorque > -0.3) )
{

count++;
    if (count >100)
    {
        antigen[6]='0';
        antigen[7]='0';
        antigen[8]='0';
        current_epitope[4]=antigen[7];
        current_epitope[5]=antigen[8];
        count = 0;
    }
}
if (rightMotorTorque > 0.3 || rightMotorTorque < -0.3)
{
 //int county;
    county++;
    if (county >200)
    {
        antigen[6]='1';
        antigen[7]='1';
        antigen[8]='1';
        current_epitope[4]=antigen[7];
        current_epitope[5]=antigen[8];
        county=0;
    }
}
/*else if (rightMotorTorque < 0.3 || rightMotorTorque > -0.3)
{

county++;
    if (county >20)
    {
        antigen[6]='1';
        antigen[7]='0';
        antigen[8]='0';
        current_epitope[4]=antigen[7];
        current_epitope[5]=antigen[8];
        county = 0;
    }
//binary_string=epitope[0]epitope[1]epitope[2]epitope[3]epitope[4]epitope[5]epitope[5]epitope[6]epitope[7]epitope[8];
}*/
}

void callbackGripper(const sensor_msgs::JointStateConstPtr &msg4)
{
//float gripperTorque = msg4->effort[4]; //Torque of gripper
 float gripperTorque = msg4->effort[88]; //Torque of gripper---FORS2
if (gripperTorque>1 || gripperTorque<-1 )
{
antigen[9]='1';		//Gripper Motor
antigen[10]='1';		//Overloading
antigen[11]='1';		//Overloading
current_epitope[6]=antigen[10];
current_epitope[7]=antigen[11];}
else
{antigen[9]='1';
antigen[10]='0';
antigen[11]='0';
current_epitope[6]=antigen[10];
current_epitope[7]=antigen[11];
}

}
void callbackScanner(const sensor_msgs::LaserScanConstPtr &msg5)
{

}
void callbackInflammation(const geometry_msgs::PoseConstPtr &msg6)
{
 depletion_rate=msg6->position.x;
}
void callbackBumpSensors(const geometry_msgs::PoseConstPtr &msg7)
{
	float b_hit=msg7->position.x;
	float bl_hit=msg7->position.y;
	float br_hit=msg7->position.z;
	float l_hit=msg7->orientation.x;
	float r_hit=msg7->orientation.y;
	float fl_hit=msg7->orientation.z;
	float fr_hit=msg7->orientation.w;
if (b_hit == 0 && bl_hit == 0 && br_hit == 0 && fl_hit == 0 && fr_hit == 0 && l_hit == 0 && r_hit == 0 )
{
antigen[12]='1';		//back bump sensors
antigen[13]='1';		//back bump sensors
antigen[14]='0';		//at a safe distance
current_epitope[8]=antigen[14];
}
else
{
antigen[12]='1';		//back bump sensors
antigen[13]='1';		//back bump sensors
antigen[14]='1';		//Hit
current_epitope[8]=antigen[14];
}
/*if (b_hit == 1)
{
antigen[12]='1';		//back bump sensors
antigen[13]='1';		//back bump sensors
antigen[14]='1';		//Hit
current_epitope[8]=antigen[14];
}
if (bl_hit == 1)
{
antigen[12]='1';		//back bump sensors
antigen[13]='1';		//back bump sensors
antigen[14]='1';		//Hit
current_epitope[8]=antigen[14];
}
if (br_hit == 1)
{
ROS_INFO("HIT");
antigen[12]='1';		//back bump sensors
antigen[13]='1';		//back bump sensors
antigen[14]='1';		//Hit
current_epitope[8]=antigen[14];
}
 if (fl_hit == 0 && fr_hit == 0)
{
antigen[12]='0';		//front bump sensors
antigen[13]='0';		//front bump sensors
antigen[14]='0';		//at a safe distance
current_epitope[8]=antigen[14];
}
 if (fr_hit == 1)
{
antigen[12]='0';		//front bump sensor
antigen[13]='0';		//front bump sensor
antigen[14]='1';		//Hit
current_epitope[8]=antigen[14];
}
 if (fl_hit == 1)
{
antigen[12]='0';		//front bump sensor
antigen[13]='0';		//front bump sensor
antigen[14]='1';		//Hit
current_epitope[8]=antigen[14];
}
if (l_hit == 0)
{
antigen[12]='0';		//left bump sensor
antigen[13]='1';		//left bump sensor
antigen[14]='0';		//at a safe distance
current_epitope[8]=antigen[14];
}
 if (l_hit == 1)
{
antigen[12]='0';		//left bump sensor
antigen[13]='1';		//left bump sensor
antigen[14]='1';		//hit
current_epitope[8]=antigen[14];
}
if (r_hit == 0)
{
antigen[12]='1';		//right bump sensor
antigen[13]='0';		//right bump sensor
antigen[14]='0';		//at a safe distance
current_epitope[8]=antigen[14];
}
if (r_hit == 1)
{
antigen[12]='1';		//right bump sensor
antigen[13]='0';		//right bump sensor
antigen[14]='1';		//hit
current_epitope[8]=antigen[14];
}
ROS_INFO_STREAM("rOBOT hits:"<<current_epitope[8]);
std::string str(current_epitope);
str=current_epitope;
binary_string.key=str;
pub1.publish(binary_string);
//ros::Duration(20).sleep();
ros::spinOnce();
*/
  }
void callbackBattery(const geometry_msgs::Vector3ConstPtr &msg3)
{
float batt_level=msg3->z;
if (batt_level<2000)
{
antigen[3]='1';		//Gripper Motor
antigen[4]='1';		//Overloading
antigen[5]='1';		//Overloading
current_epitope[2]=antigen[4];
current_epitope[3]=antigen[5];}
else if (batt_level>2000 )
{antigen[3]='1';
antigen[4]='0';
antigen[5]='0';
current_epitope[2]=antigen[4];
current_epitope[3]=antigen[5];
current_epitope[9]='0';
}
std::string str(current_epitope);
str=current_epitope;
binary_string.key=str;
pub1.publish(binary_string);
//ros::Duration(20).sleep();
ros::spinOnce();
ROS_INFO_STREAM("TRY"<<str);
/*else if (batt_level>2000 )
{antigen[3]='1';
antigen[4]='0';
antigen[5]='1';
current_epitope[2]=antigen[4];
current_epitope[3]=antigen[5];
}*/
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "antigen");
    ros::NodeHandle nh;
    	pub = nh.advertise<geometry_msgs::Quaternion>("/antigen", 10);
	pub1 = nh.advertise<robot_adaptive_immune_system::strng>("/status", 10);
	ros::Subscriber sub1 = nh.subscribe("/Inflammation", 10, callbackInflammation);
	ros::Subscriber sub2 = nh.subscribe("/joint_state", 10, callbackGripper);
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            ros::Subscriber sub3 = nh.subscribe("/joint_state",10,callbackMotors);
	ros::Subscriber sub4 = nh.subscribe("/joint_state", 10, callbackMotors);
	ros::Subscriber sub6 = nh.subscribe("/AT", 10, callbackControllers);
	ros::Subscriber sub7 = nh.subscribe("/Hit", 10, callbackBumpSensors);
	ros::Subscriber sub5 = nh.subscribe("/Energy", 10, callbackBattery);
	//ros::Subscriber sub2 = nh.subscribe("/epitope",1, callbackAntigen);
	ros::spin();
    return 0;
}
