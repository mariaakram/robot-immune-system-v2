// ROS node for bump sensors
// ==========================
#include <ros/ros.h>
#include <geometry_msgs/Pose.h>
#include <std_msgs/Int32.h>
    ros::Publisher pub;
    float h1,h2,h3,h4,h5,h6,h7,h8;
void callbackHitB(const std_msgs::Int32ConstPtr &bmpB)
{
h1= bmpB->data;
//ROS_INFO_STREAM( "Recieved1: " << bmpB->data);
}
void callbackHitL(const std_msgs::Int32ConstPtr &bmpL)
{
h4= bmpL->data;
//ROS_INFO_STREAM( "Recieved2: " << bmpL->data);
}
void callbackHitR(const std_msgs::Int32ConstPtr &bmpR)
{
h5= bmpR->data;
//ROS_INFO_STREAM( "Recieved3: " << bmpR->data);
}
void callbackHitF(const std_msgs::Int32ConstPtr &bmpF)
{
h8= bmpF->data;
//ROS_INFO_STREAM( "Recieved4: " << bmpF->data);
}
void callbackHitFL(const std_msgs::Int32ConstPtr &bmpFL)
{
h6= bmpFL->data;
//ROS_INFO_STREAM( "Recieved5: " << bmpFL->data);
}
void callbackHitFR(const std_msgs::Int32ConstPtr &bmpFR)
{
h7= bmpFR->data;
//ROS_INFO_STREAM( "Recieved6: " << bmpFR->data);
}
void callbackHitBR(const std_msgs::Int32ConstPtr &bmpBR)
{
h3= bmpBR->data;
//ROS_INFO_STREAM( "Recieved7: " << bmpBR->data);
}
void callbackHitBL(const std_msgs::Int32ConstPtr &bmpBL)
{
h2= bmpBL->data;
//ROS_INFO_STREAM( "Recieved8: " << bmpBL->data);
	geometry_msgs::Pose ht;

		ht.position.x = h1;
		ht.position.y = h2;
		ht.position.z = h3;
		ht.orientation.x = h4;
		ht.orientation.y = h5;
		ht.orientation.z = h6;
		ht.orientation.z = h7;
		pub.publish(ht);
	//ROS_INFO("publishing hit detail");
	ros::spinOnce();}

int main(int argc, char **argv)
{
   	ros::init(argc, argv, "bump_sensors");
    	ros::NodeHandle nh;
    			pub = nh.advertise<geometry_msgs::Pose>("/Hit", 10);
		ros::Subscriber sub = nh.subscribe("/bumpB", 10, callbackHitB);
    		ros::Subscriber	sub1 = nh.subscribe("/bumpF", 10, callbackHitF);
		ros::Subscriber sub4 = nh.subscribe("/bumpR", 10, callbackHitR);
		ros::Subscriber sub3 = nh.subscribe("/bumpFL", 10, callbackHitFL);
		ros::Subscriber sub2 = nh.subscribe("/bumpBL", 10, callbackHitBL);
		ros::Subscriber sub5 = nh.subscribe("/bumpBR", 10, callbackHitBR);
		ros::Subscriber sub6 = nh.subscribe("/bumpL", 10, callbackHitL);
		ros::Subscriber sub7 = nh.subscribe("/bumpFR", 10, callbackHitFR);
	ros::spin();
return 0;
}


