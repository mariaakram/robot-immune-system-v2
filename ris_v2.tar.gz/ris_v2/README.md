***********************************************************
ris_v2 user manual
GNU General Public License:
Copyright (c).2019. OWNER: University of Engineering and Technology, Lahore, Pakistan.
@authors: Maria Akram, Ali Raza. ( mariaakram86@gmail.com, ali.raza@ymail.com)
Please write to us if you have any question or if there is any problem.
All rights reserved.
***********************************************
Running the simulations
***********************************************
Note :  Please open separate terminals to launch different launch files.

1.	Copy the folder ris_v2 and paste it in the catkin_ws/src folder.
2.	Enter the below mentioned instructions in the terminal, one by one, to install some existing packages which will assist ris_v2:

	sudo apt-get install ros-indigo-diagnostic-common-diagnostics
	sudo apt-get install ros-indigo-gmapping
	sudo apt-get install ros-indigo-move-base
	sudo apt-get install ros-indigo-rqt-multiplot

3.	After the installation of these packages type and enter the following instructions in the terminal windows. 
	
	 $ roslaunch ris_v2 innate_immune_functions.launch
	 $ roslaunch ris_v2 adaptive_immune_functions.launch	
	
4.	For graphical visualization of how the various immune functions help to maintain robot health open 		  rqt_multiplot by typing the following instruction in another terminal window:
	
	rosrun rqt_multiplot rqt_multiplot
	
	This will open up a new window. In this window click "Open configuration" tab on the top-right corner and 		choose the file located ris_v2/plot/rqt_multiplot.xml and then click "Run all plots". 

5.	Navigate the robot using keys mentioned in teleop_twist_keyboard window

	Try to intentionally hit the robot with some obstacle and observe how this behaviour is considered as an 		unhealthy state due to high energy consumption rate and increased temperature of motors. The RIS will then 		try to maintain robot health through various recovery action at different immune levels which can also be 		observed in rqt_multiplot window.
6.	Kill rosnode that publishes data for bump sensors.
	$ rosnode kill /bump_sensors 
	Observe the recovery actions of the robot after hitting any obstacle without having any information from bump 		sensors. 
*****************USER EXTENSION**************************************************
User can implement the RIS for its own robot as:
1. Provide the information of motors and sensors of your robot to inflammation, Reactive immune cells and T-cells 	  nodes. 
2. Run everything as above
*****************IMPORTANT*******************************************************
THE STACK IS STILL UNDER WORK AT THE MOMENT, THEREFORE YOUR FEEDBACK 
WILL BE HIGHLY APPRECIATED. 
IF YOU HAVE ANY QUESTION, PLEASE EMAIL TO szaman@ist.tugraz.at
Thanks.
Next Version will be uploaded soon.
*****************************************************************	

 
# robot-immune-system-v2
